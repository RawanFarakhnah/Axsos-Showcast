from django.apps import AppConfig


class VintageCarsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'vintage_cars_app'
